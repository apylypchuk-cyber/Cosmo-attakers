import os, pygame, sys
from player import Player
import obstacle
from alien import Alien, Extra
from random import choice, randint
from laser import Laser

# Imports game modules, sprite classes, and utility functions used by the game.

# Main game manager class handles gameplay state, rendering, input, and leaderboard flow.
class Game:
	def __init__(self, volume = 0.2):
		# Initialize the main game state, including player, obstacles, aliens, and audio.
		# Player setup
		player_sprite = Player((screen_width / 2,screen_height),screen_width,5,screen_height)
		self.player = pygame.sprite.GroupSingle(player_sprite)

		# health and score setup
		self.lives = 3
		self.live_surf = pygame.image.load('../graphics/player.png').convert_alpha()
		self.live_x_start_pos = screen_width - (self.live_surf.get_size()[0] * 2 + 20)
		self.score = 0
		self.font = pygame.font.Font('../font/Pixeled.ttf',20)
		self.game_over = False
		self.victory = False
		self.volume = volume
		self.saved_name = None
		self.save_mode = False
		self.name_input = ''
		self.name_error = ''
		self.saved = False
		self.current_screen = 'menu'
		self.leaderboard_path = os.path.join(os.path.dirname(__file__), 'leaderboard.txt')
		self.leaderboard = self.load_leaderboard()
		self.leaderboard_page = 0

		# Obstacle setup
		self.shape = obstacle.shape
		self.block_size = 6
		self.blocks = pygame.sprite.Group()
		self.obstacle_amount = 4
		self.obstacle_x_positions = [num * (screen_width / self.obstacle_amount) for num in range(self.obstacle_amount)]
		self.create_multiple_obstacles(*self.obstacle_x_positions, x_start = screen_width / 15, y_start = 480)

		# Alien setup
		self.aliens = pygame.sprite.Group()
		self.alien_lasers = pygame.sprite.Group()
		self.wave = 1
		self.alien_setup(rows = 6, cols = 8)
		self.alien_direction = 1

		# Extra setup
		self.extra = pygame.sprite.GroupSingle()
		self.extra_spawn_time = randint(40,80)

		# Audio
		self.music = pygame.mixer.Sound('../audio/music.wav')
		self.laser_sound = pygame.mixer.Sound('../audio/laser.wav')
		self.explosion_sound = pygame.mixer.Sound('../audio/explosion.wav')
		self.set_volume(volume)
		self.music.play(loops = -1)

	def set_volume(self, volume):
		# Apply volume settings to all music and sound effects.
		self.music.set_volume(volume)
		self.laser_sound.set_volume(0.5 * volume)
		self.explosion_sound.set_volume(0.3 * volume)

	def load_leaderboard(self):
		# Load leaderboard entries from disk and sort them by score.
		entries = []
		if os.path.exists(self.leaderboard_path):
			with open(self.leaderboard_path, 'r', encoding='utf-8') as file:
				for line in file:
					parts = line.strip().split(',')
					if len(parts) == 3 and parts[1].isdigit() and parts[2].isdigit():
						entries.append((parts[0], int(parts[1]), int(parts[2])))
					elif len(parts) == 2 and parts[1].isdigit():
						entries.append((parts[0], int(parts[1]), 1))
		entries.sort(key=lambda item: item[1], reverse=True)
		return entries

	def save_score(self, name):
		# Validate the player name, add the score to the leaderboard, and write it to file.
		name = name.strip().upper()
		if not name or len(name) > 10:
			return False
		entries = self.load_leaderboard()
		entries.append((name, self.score, self.wave))
		entries.sort(key=lambda item: item[1], reverse=True)
		entries = entries[:50]
		with open(self.leaderboard_path, 'w', encoding='utf-8') as file:
			for entry_name, entry_score, entry_wave in entries:
				file.write(f'{entry_name},{entry_score},{entry_wave}\n')
		self.leaderboard = entries
		self.saved_name = name.strip().upper()
		return True

	def get_player_best_entry(self, name):
		# Return the best saved score, place, and wave for a given player name.
		name = (name or '').strip().upper()
		best_score = None
		best_wave = None
		for entry_name, entry_score, entry_wave in self.leaderboard:
			if entry_name == name:
				if best_score is None or entry_score > best_score:
					best_score = entry_score
					best_wave = entry_wave
		if best_score is None:
			return None, None, None
		place = 1
		for entry_name, entry_score, _ in self.leaderboard:
			if entry_score > best_score:
				place += 1
		return best_score, place, best_wave

	def get_player_best_place(self, name):
		# Return the best saved score and rank for a player name.
		name = name.strip().upper()
		best_score = None
		for entry_name, entry_score, _ in self.leaderboard:
			if entry_name == name:
				if best_score is None or entry_score > best_score:
					best_score = entry_score
		if best_score is None:
			return None, None
		place = 1
		for entry_name, entry_score, _ in self.leaderboard:
			if entry_score > best_score:
				place += 1
		return best_score, place

	def get_score_place(self, score):
		# Estimate leaderboard position for the current score.
		place = 1
		for _, entry_score, _ in self.leaderboard:
			if entry_score > score:
				place += 1
		return place

	def format_leaderboard_entry(self, index, entry):
		# Convert a leaderboard tuple into a formatted display string.
		return f'{index}. "{entry[0]}" score : {entry[1]} wave : {entry[2]}'

	def draw_main_menu(self):
		# Draw the main menu with options for starting the game, viewing leaderboard, volume, and exit.
		screen.fill((30, 30, 30))

		title = self.font.render('COSMO ATTACKERS', False, (0, 128, 0))
		title_rect = title.get_rect(center=(screen_width / 2, 75))
		screen.blit(title, title_rect)

		menu_items = [
			'Start (SPACE)',
			'Leaderboard (L)',
			f'Volume {int(self.volume * 100)} (V)',
			'Exit (E)'
		]
		for idx, item in enumerate(menu_items):
			menu_surf = self.font.render(item, False, 'white')
			menu_rect = menu_surf.get_rect(center=(screen_width / 2, 150 + idx * 45))
			screen.blit(menu_surf, menu_rect)

	def draw_leaderboard_screen(self):
		# Render the leaderboard page, entries, and navigation controls.
		screen.fill((30, 30, 30))

		leaderboard_title = self.font.render('Leaderboard', False, 'white')
		leaderboard_rect = leaderboard_title.get_rect(center=(screen_width / 2, 60))
		screen.blit(leaderboard_title, leaderboard_rect)

		entries_per_page = 10
		page_count = max(1, (len(self.leaderboard) + entries_per_page - 1) // entries_per_page)
		self.leaderboard_page = max(0, min(self.leaderboard_page, page_count - 1))
		page_text = self.font.render(f'Page {self.leaderboard_page + 1}/{page_count}', False, 'white')
		page_rect = page_text.get_rect(center=(screen_width / 2, 100))
		screen.blit(page_text, page_rect)

		# Render leaderboard entries with a smaller font to avoid overlap
		small_font = pygame.font.Font('../font/Pixeled.ttf', 14)
		for idx, entry in enumerate(self.leaderboard[self.leaderboard_page * entries_per_page:(self.leaderboard_page + 1) * entries_per_page], start=1):
			entry_text = small_font.render(self.format_leaderboard_entry(self.leaderboard_page * entries_per_page + idx, entry), False, 'white')
			entry_rect = entry_text.get_rect(topleft=(70, 120 + idx * 22))
			screen.blit(entry_text, entry_rect)

		footer = self.font.render('A previous | D next | L Menu', False, 'white')
		footer_rect = footer.get_rect(center=(screen_width / 2, screen_height - 50))
		screen.blit(footer, footer_rect)

	def change_volume(self):
		# Cycle the volume and apply new settings immediately.
		new_volume = round((self.volume + 0.1) * 10) / 10
		if new_volume > 1.0:
			new_volume = 0.0
		self.volume = new_volume
		self.set_volume(self.volume)

	def draw_save_screen(self):
		# Render the score saving UI with name entry and validation text.
		screen.fill((30, 30, 30))

		title = self.font.render('Save Your Score', False, 'white')
		title_rect = title.get_rect(center=(screen_width / 2, 75))
		screen.blit(title, title_rect)

		prompt = self.font.render('Allowed: A-Z 0-9, max 10 chars', False, 'white')
		prompt_rect = prompt.get_rect(center=(screen_width / 2, 115))
		screen.blit(prompt, prompt_rect)

		box_w = 360
		box_h = 40
		box_x = (screen_width - box_w) // 2
		box_y = 145
		box_rect = pygame.Rect(box_x, box_y, box_w, box_h)
		pygame.draw.rect(screen, (24, 24, 24), box_rect)
		pygame.draw.rect(screen, (105, 105, 105), box_rect, 2)

		input_text = self.font.render(self.name_input or '_', False, 'white')
		input_rect = input_text.get_rect(midleft=(box_rect.left + 12, box_rect.centery))
		screen.blit(input_text, input_rect)

		status = self.font.render(self.name_error or 'Type your name', False, 'white')
		status_rect = status.get_rect(center=(screen_width / 2, 210))
		screen.blit(status, status_rect)

		score_text = self.font.render(f'Score: {self.score}', False, 'white')
		score_rect = score_text.get_rect(center=(screen_width / 2, 250))
		screen.blit(score_text, score_rect)

		if not self.saved:
			predicted_place = self.get_score_place(self.score)
			predicted_text = self.font.render(f'Leaderboard place: {predicted_place}', False, 'white')
			predicted_rect = predicted_text.get_rect(center=(screen_width / 2, 290))
			screen.blit(predicted_text, predicted_rect)

		if self.saved:
			leaderboard_title = self.font.render('Leaderboard - Top 5', False, 'white')
			leaderboard_rect = leaderboard_title.get_rect(center=(screen_width / 2, 300))
			screen.blit(leaderboard_title, leaderboard_rect)

			small_font = pygame.font.Font('../font/Pixeled.ttf', 14)
			for i, entry in enumerate(self.leaderboard[:5], start=1):
				entry_text = small_font.render(self.format_leaderboard_entry(i, entry), False, 'white')
				entry_rect = entry_text.get_rect(topleft=(70, 325 + (i - 1) * 24))
				screen.blit(entry_text, entry_rect)

			best_score, best_place, best_wave = self.get_player_best_entry(self.saved_name or self.name_input)
			if best_score is not None:
				# compute positions so Place/Wave sits above the restart/exit prompts
				restart_y = screen_height - 70
				exit_y = screen_height - 40
				place_y = restart_y - 42
				place_text = self.font.render(f'Place: {best_place} | Wave {best_wave}', False, 'white')
				place_rect = place_text.get_rect(center=(screen_width / 2, place_y))
				screen.blit(place_text, place_rect)

			continue_text = self.font.render('Press R to restart', False, 'white')
			continue_rect = continue_text.get_rect(center=(screen_width / 2, restart_y))
			screen.blit(continue_text, continue_rect)
			exit_text = self.font.render('Press E to exit', False, 'white')
			exit_rect = exit_text.get_rect(center=(screen_width / 2, exit_y))
			screen.blit(exit_text, exit_rect)
			return

		instructions = self.font.render('Press Enter to save', False, 'white')
		instr_rect = instructions.get_rect(center=(screen_width / 2, 325))
		screen.blit(instructions, instr_rect)

	def create_obstacle(self, x_start, y_start, offset_x):
		# Build one obstacle layout based on the obstacle shape template.
		for row_index, row in enumerate(self.shape):
			for col_index, col in enumerate(row):
				if col == 'x':
					x = x_start + col_index * self.block_size + offset_x
					y = y_start + row_index * self.block_size
					block = obstacle.Block(self.block_size, (0, 128, 0), x, y)
					self.blocks.add(block)

	def create_multiple_obstacles(self, *offset, x_start, y_start):
		# Create several obstacles in a row using the given offsets.
		for offset_x in offset:
			self.create_obstacle(x_start, y_start, offset_x)

	def alien_setup(self, rows, cols, x_distance = 60, y_distance = 48, x_offset = 70, y_offset = 140):
		# Spawn aliens in rows and color-code them by row.
		for row_index in range(rows):
			for col_index in range(cols):
				x = col_index * x_distance + x_offset
				y = row_index * y_distance + y_offset
				if row_index == 0:
					alien_sprite = Alien('yellow', x, y)
				elif 1 <= row_index <= 2:
					alien_sprite = Alien('green', x, y)
				else:
					alien_sprite = Alien('red', x, y)
				self.aliens.add(alien_sprite)

		if self.aliens:
			min_left = min(a.rect.left for a in self.aliens.sprites())
			max_right = max(a.rect.right for a in self.aliens.sprites())
			margin = 50
			if min_left < margin:
				shift = margin - min_left
				for a in self.aliens.sprites():
					a.rect.x += shift
			if max_right > screen_width - margin:
				shift = (screen_width - margin) - max_right
				for a in self.aliens.sprites():
					a.rect.x += shift

	def alien_position_checker(self):
		if self.aliens:
			min_left = min(a.rect.left for a in self.aliens.sprites())
			max_right = max(a.rect.right for a in self.aliens.sprites())
			margin = 50
			# shift right if too close to left edge
			if min_left < margin:
				shift = margin - min_left
				for a in self.aliens.sprites():
					a.rect.x += shift
			# shift left if too close to right edge
			if max_right > screen_width - margin:
				shift = (screen_width - margin) - max_right
				for a in self.aliens.sprites():
					a.rect.x += shift

	def alien_position_checker(self):
		# Detect if the alien group reached a screen edge and reverse direction.
		if not self.aliens:
			return

		move_left = any(alien.rect.left <= 0 for alien in self.aliens)
		move_right = any(alien.rect.right >= screen_width for alien in self.aliens)

		if move_right:
			self.alien_direction = -1
			self.alien_move_down(2)
		elif move_left:
			self.alien_direction = 1
			self.alien_move_down(2)

	def alien_move_down(self,distance):
		# Move every alien down by the specified distance.
		if self.aliens:
			for alien in self.aliens.sprites():
				alien.rect.y += distance

	def alien_shoot(self):
		# Let a random alien shoot a laser if the game is still active.
		if self.game_over:
			return
		if self.aliens.sprites():
			random_alien = choice(self.aliens.sprites())
			laser_sprite = Laser(random_alien.rect.center,6,screen_height)
			self.alien_lasers.add(laser_sprite)
			self.laser_sound.play()

	def extra_alien_timer(self):
		# Decrease the extra enemy timer and spawn one when it reaches zero.
		self.extra_spawn_time -= 1
		if self.extra_spawn_time <= 0:
			self.extra.add(Extra(choice(['right','left']),screen_width))
			self.extra_spawn_time = randint(400,800)

	def collision_checks(self):
		# Perform all collision checks and update lives, score, wave, and game over state.
		if self.game_over:
			return

		# player lasers 
		if self.player.sprite.lasers:
			for laser in self.player.sprite.lasers:
				# obstacle collisions
				if pygame.sprite.spritecollide(laser,self.blocks,True):
					laser.kill()

				# alien collisions
				aliens_hit = pygame.sprite.spritecollide(laser,self.aliens,True)
				if aliens_hit:
					for alien in aliens_hit:
						self.score += alien.value
					laser.kill()
					self.explosion_sound.play()

				# extra collision
				if pygame.sprite.spritecollide(laser,self.extra,True):
					self.score += 500
					laser.kill()

		# alien lasers 
		if self.alien_lasers:
			for laser in self.alien_lasers:
				# obstacle collisions
				if pygame.sprite.spritecollide(laser,self.blocks,True):
					laser.kill()

				if pygame.sprite.spritecollide(laser,self.player,False):
					laser.kill()
					self.lives -= 1
					if self.lives <= 0:
						self.lives = 0
						self.game_over = True
						return

		# aliens
		if self.aliens:
			for alien in self.aliens:
				pygame.sprite.spritecollide(alien,self.blocks,True)

				if pygame.sprite.spritecollide(alien,self.player,False):
					self.lives = 0
					self.game_over = True
					return

				if alien.rect.bottom >= screen_height:
					self.lives = 0
					self.game_over = True
					return

		if not self.aliens:
			# Spawn next wave instead of victory
			self.wave += 1
			self.alien_setup(rows = 6, cols = 8)
			return

	def display_lives(self):
		# Draw the player's remaining lives as icons.
		for live in range(self.lives - 1):
			x = self.live_x_start_pos + (live * (self.live_surf.get_size()[0] + 10))
			screen.blit(self.live_surf,(x,8))

	def display_score(self):
		# Display the current score at the top-left of the screen.
		score_surf = self.font.render(f'score: {self.score}',False,'white')
		score_rect = score_surf.get_rect(topleft = (10,-10))
		screen.blit(score_surf,score_rect)

	def display_wave(self):
		# Display the current wave number below the score.
		wave_surf = self.font.render(f'wave: {self.wave}',False,'white')
		wave_rect = wave_surf.get_rect(topleft = (10,15))
		screen.blit(wave_surf,wave_rect)

	def victory_message(self):
		# Draw the victory screen and save/restart prompts after win.
		if self.victory and self.game_over:
			victory_surf = self.font.render('You won',False,'white')
			victory_rect = victory_surf.get_rect(center = (screen_width / 2, screen_height / 2 - 20))
			screen.blit(victory_surf,victory_rect)
			score_surf = self.font.render(f'Score: {self.score}',False,'white')
			score_rect = score_surf.get_rect(center = (screen_width / 2, screen_height / 2 + 10))
			screen.blit(score_surf,score_rect)
			restart_surf = self.font.render('Press R to restart',False,'white')
			restart_surf = pygame.transform.scale(restart_surf, (int(restart_surf.get_width() * 0.75), int(restart_surf.get_height() * 0.75)))
			restart_rect = restart_surf.get_rect(center = (screen_width / 2, screen_height / 2 + 50))
			screen.blit(restart_surf,restart_rect)
			exit_surf = self.font.render('Press E to exit', False, 'white')
			exit_surf = pygame.transform.scale(exit_surf, (int(exit_surf.get_width() * 0.75), int(exit_surf.get_height() * 0.75)))
			exit_rect = exit_surf.get_rect(center = (screen_width / 2, screen_height / 2 + 80))
			screen.blit(exit_surf, exit_rect)
			save_text = 'Results saved' if self.saved else 'Press S to save results'
			save_surf = self.font.render(save_text,False,'white')
			save_surf = pygame.transform.scale(save_surf, (int(save_surf.get_width() * 0.75), int(save_surf.get_height() * 0.75)))
			save_rect = save_surf.get_rect(center = (screen_width / 2, screen_height / 2 + 110))
			screen.blit(save_surf,save_rect)

	def defeat_message(self):
		# Draw the defeat screen and save/restart prompts after loss.
		if self.game_over and not self.victory:
			defeat_surf = self.font.render('Game Over',False,'white')
			defeat_rect = defeat_surf.get_rect(center = (screen_width / 2, screen_height / 2 - 20))
			screen.blit(defeat_surf,defeat_rect)
			score_surf = self.font.render(f'Score: {self.score}',False,'white')
			score_rect = score_surf.get_rect(center = (screen_width / 2, screen_height / 2 + 10))
			screen.blit(score_surf,score_rect)
			restart_surf = self.font.render('Press R to restart',False,'white')
			restart_surf = pygame.transform.scale(restart_surf, (int(restart_surf.get_width() * 0.75), int(restart_surf.get_height() * 0.75)))
			restart_rect = restart_surf.get_rect(center = (screen_width / 2, screen_height / 2 + 50))
			screen.blit(restart_surf,restart_rect)
			exit_surf = self.font.render('Press E to exit', False, 'white')
			exit_surf = pygame.transform.scale(exit_surf, (int(exit_surf.get_width() * 0.75), int(exit_surf.get_height() * 0.75)))
			exit_rect = exit_surf.get_rect(center = (screen_width / 2, screen_height / 2 + 80))
			screen.blit(exit_surf, exit_rect)
			save_text = 'Results saved' if self.saved else 'Press S to save results'
			save_surf = self.font.render(save_text,False,'white')
			save_surf = pygame.transform.scale(save_surf, (int(save_surf.get_width() * 0.75), int(save_surf.get_height() * 0.75)))
			save_rect = save_surf.get_rect(center = (screen_width / 2, screen_height / 2 + 110))
			screen.blit(save_surf,save_rect)

	def run(self):
		# Main per-frame update and render call for the current game state.
		if self.current_screen == 'menu':
			self.draw_main_menu()
			return

		if self.current_screen == 'leaderboard':
			self.draw_leaderboard_screen()
			return

		if not self.game_over:
			self.player.update()
			self.alien_lasers.update()
			self.extra.update()
			self.aliens.update(self.alien_direction)
			self.alien_position_checker()
			self.collision_checks()
			self.extra_alien_timer()
		self.player.sprite.lasers.draw(screen)
		self.player.draw(screen)
		self.blocks.draw(screen)
		self.aliens.draw(screen)
		self.alien_lasers.draw(screen)
		self.extra.draw(screen)
		self.display_lives()
		self.display_score()
		self.display_wave()
		self.victory_message()
		self.defeat_message()
		if self.save_mode or self.saved:
			self.draw_save_screen()

# CRT overlay class draws a retro scanline effect over the game.
class CRT:
	def __init__(self):
		self.tv = pygame.image.load('../graphics/tv.png').convert_alpha()
		self.tv = pygame.transform.scale(self.tv,(screen_width,screen_height))

	def create_crt_lines(self):
		line_height = 3
		line_amount = int(screen_height / line_height)
		for line in range(line_amount):
			y_pos = line * line_height
			pygame.draw.line(self.tv,'black',(0,y_pos),(screen_width,y_pos),1)

	def draw(self):
		self.tv.set_alpha(randint(75,90))
		self.create_crt_lines()
		screen.blit(self.tv,(0,0))

if __name__ == '__main__':
	# Initialize pygame, screen, clock, and game objects.
	pygame.init()
	screen_width = 600
	screen_height = 600
	screen = pygame.display.set_mode((screen_width,screen_height))
	clock = pygame.time.Clock()
	game = Game()
	crt = CRT()

	ALIENLASER = pygame.USEREVENT + 1
	pygame.time.set_timer(ALIENLASER,800)

	while True:
		# Game loop: process input, update state, render, and cap the frame rate.
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			if event.type == ALIENLASER and game.current_screen == 'game' and not game.game_over:
				# Periodic alien shooting event triggered by a timer.
				game.alien_shoot()
			if event.type == pygame.KEYDOWN:
				# Handle keyboard input for menu navigation, gameplay screens, and saving.
				# Allow opening save dialog from victory/defeat screens with S
				if (game.game_over or game.victory) and event.key == pygame.K_s and not game.saved and not game.save_mode:
					game.save_mode = True
					game.name_input = ''
					game.name_error = ''
					continue
				if game.current_screen == 'menu':
					# Menu controls for starting the game, changing volume, viewing leaderboard, or exiting.
					if event.key == pygame.K_SPACE:
						# Always start a fresh game when pressing SPACE from the menu
						pygame.mixer.stop()
						game = Game()
						game.current_screen = 'game'
					elif event.key == pygame.K_l:
						game.current_screen = 'leaderboard'
					elif event.key == pygame.K_v:
						game.change_volume()
					elif event.key == pygame.K_e:
						pygame.quit()
						sys.exit()
				elif game.current_screen == 'leaderboard':
					# Leaderboard navigation controls and returning to the menu.
					if event.key == pygame.K_a:
						game.leaderboard_page = max(0, game.leaderboard_page - 1)
					elif event.key == pygame.K_d:
						game.leaderboard_page += 1
					elif event.key == pygame.K_l:
						game.current_screen = 'menu'
					elif event.key == pygame.K_v:
						game.change_volume()
					elif event.key == pygame.K_e:
						pygame.quit()
						sys.exit()
				else:
					if game.save_mode:
						# Save-mode keyboard handling for typing the player name.
						if event.key == pygame.K_BACKSPACE:
							game.name_input = game.name_input[:-1]
						# Attempt to save the entered name and score when Enter is pressed.
						elif event.key == pygame.K_RETURN:
							if game.name_input:
								if game.save_score(game.name_input):
									game.saved = True
									game.save_mode = False
								else:
									game.name_error = 'Invalid name, use 1-10 letters/numbers.'
							else:
								game.name_error = 'Enter a name before saving.'
						elif event.unicode.isalnum() and len(game.name_input) < 10:
							game.name_input += event.unicode.upper()
					elif game.saved:
						# Saved result screen handles restart or return to menu.
						if event.key == pygame.K_r:
							pygame.mixer.stop()
							game = Game()
							game.current_screen = 'game'
						elif event.key == pygame.K_e:
							game.current_screen = 'menu'
							game.game_over = False
							game.victory = False
							game.saved = False
					else:
						# If player has just won or lost (and not in save_mode), allow R/E
						if (game.game_over or game.victory) and not game.save_mode and not game.saved:
							if event.key == pygame.K_r:
								pygame.mixer.stop()
								game = Game()
								game.current_screen = 'game'
							elif event.key == pygame.K_e:
								game.current_screen = 'menu'
								game.game_over = False
								game.victory = False
						else:
							if event.key == pygame.K_s and game.game_over and not game.saved:
								game.save_mode = True
								game.name_input = ''
								game.name_error = ''

		screen.fill((30,30,30))
		game.run()
		crt.draw()
			
		pygame.display.flip()
		clock.tick(60)